"""
place_order:
Creates a new order.
Steps include selecting product, size, quantity,
asking user confirmation, and completing payment.
Requires human confirmation before payment.
"""

from langgraph.graph import StateGraph
from state.state import OrderState
from langgraph.types import interrupt
from llm.groq import get_llm

from graph.tools_llm.product_tool import TOOLS
from graph.tools.product_recom import product_recommendation_graph
from graph.tools_llm.product_validate import product_validate_graph


def extract_product(state: OrderState):
    words = state["input"].lower().split()
    product = words[-1]
    return {
        "product": product,
        "messages": [f"User requested product: {product}"]
    }

llm = get_llm()

ROUTER_TOOLS = {
    "validate": product_validate_graph.__doc__,
    "recommend": product_recommendation_graph.__doc__,
}

def product_router_llm(state: OrderState):
    prompt = f"""
User selected product: {state.get("product")}

Available actions:
{ROUTER_TOOLS}

If product is available → return "validate"
If product is unavailable → return "recommend"

Return ONLY one word.
"""
    decision = llm.invoke(prompt).content.strip()
    return decision

def ask_product_again(state: OrderState):
    return interrupt(
        "Product unavailable. Please enter a product to continue:"
    )

def place_order(state:OrderState):
    if not state.get("confirmation"):
        return interrupt("Confirm order? (yes/no)")
    
    if state.get("confirmation").lower() == "no":
        return {
            "messages": [
                "Order was not placed."
            ]
        }

    return {
        "messages": [
            "Order confirmed",
        ]
    }


builder = StateGraph(OrderState)

# Product selection via TOOL REGISTRY
builder.add_node("select_product", TOOLS["product"])

# Availability / recommendation
builder.add_node("extract_product", extract_product)
builder.add_node("validate_product", product_validate_graph)
builder.add_node("recommend_product", product_recommendation_graph)
builder.add_node("ask_product", ask_product_again)

# Normal flow tools
builder.add_node("select_size", TOOLS["size"])
builder.add_node("select_quantity", TOOLS["quantity"])
builder.add_node("confirm_order", place_order)
builder.add_node("payment", TOOLS["payment"])

builder.set_entry_point("extract_product")

# Decide validate vs recommend using LLM + docstrings
builder.add_edge("extract_product", "select_product")
builder.add_edge("select_product", "validate_product")

builder.add_conditional_edges(
    "select_product",
    product_router_llm,
    {
        "validate": "validate_product",
        "recommend": "recommend_product",
    }
)

# If recommended → ask user → re-run product tool
builder.add_edge("recommend_product", "ask_product")
builder.add_edge("ask_product", "select_product")

# Normal execution path
builder.add_edge("validate_product", "select_size")
builder.add_edge("select_size", "select_quantity")
builder.add_edge("select_quantity", "confirm_order")
builder.add_edge("confirm_order", "payment")

place_order_graph = builder.compile()

